src=zh
tgt=en
tag=${src}-${tgt}
TEXT=../data/$tag

TEXT1=../data/$tag/testset/NIST04
TEXT2=../data/$tag/testset/NIST05
TEXT3=../data/$tag/testset/NIST08
TEXT4=../data/$tag/testset/NIST06


dic=../data-bin/$tag
output=../data-bin/1_$tag
srcdict=$dic/dict.$src.txt
tgtdict=$dic/dict.$tgt.txt

#python3 preprocess.py --source-lang $src --target-lang $tgt --trainpref $TEXT/train  --validpref $TEXT/valid --testpref $TEXT/test,$TEXT/test1,$TEXT/test2 --destdir $output --workers 32
python3 preprocess.py --source-lang $src --target-lang $tgt --srcdict $srcdict --tgtdict $tgtdict --testpref $TEXT1/test,$TEXT2/test,$TEXT3/test,$TEXT4/test  --destdir $output --workers 32

#python3 preprocess.py --source-lang $src --target-lang $tgt --trainpref $TEXT/train  --validpref $TEXT/valid  --destdir $output --workers 32
